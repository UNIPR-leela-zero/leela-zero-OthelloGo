#include "config.h"

#if CURRENT_GAME == GAME_GO
#include "src/GO/KoStateGo.cpp"
#endif
