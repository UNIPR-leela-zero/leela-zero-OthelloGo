#include "config.h"

// Training.cpp (wrapper)
#if CURRENT_GAME == GAME_GO
#include "src/GO/TrainingGo.cpp"
#elif CURRENT_GAME == GAME_OTHELLO
#include "src/OTHELLO/TrainingOthello.cpp"
#else
#error "Unsupported game selected"
#endif