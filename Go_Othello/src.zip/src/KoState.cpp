#include "config.h"

#if CURRENT_GAME == GAME_GO
#include "KoStateGo.cpp"
#endif
