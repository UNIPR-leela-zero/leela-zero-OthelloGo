#ifndef KOSTATE_H_INCLUDED
#define KOSTATE_H_INCLUDED

#include "config.h"

#if CURRENT_GAME == GAME_GO
#include "src/GO/KoStateGo.h"
#endif

#endif
