#include "GameType.h"
GameType CURRENT_GAME = GameType::GO; // default
