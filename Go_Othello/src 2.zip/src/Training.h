#ifndef TRAINING_H_INCLUDED
#define TRAINING_H_INCLUDED

#include "config.h"

// Seleziona il file header appropriato in base al gioco corrente
#if CURRENT_GAME == GAME_GO
#include "src/GO/TrainingGo.h"
#elif CURRENT_GAME == GAME_OTHELLO
#include "src/OTHELLO/TrainingOthello.h"
#else
#error "Unsupported game selected"
#endif

#endif