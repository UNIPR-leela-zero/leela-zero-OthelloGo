#include "config.h"

// SGFTree.cpp (wrapper)
#if CURRENT_GAME == GAME_GO
#include "src/GO/SGFTreeGo.cpp"
#elif CURRENT_GAME == GAME_OTHELLO
#include "src/OTHELLO/SGFTreeOthello.cpp"
#else
#error "Unsupported game selected"
#endif