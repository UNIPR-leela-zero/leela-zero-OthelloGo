#include "config.h"

// FullBoard.cpp (wrapper)
#if CURRENT_GAME == GAME_GO
#include "src/GO/FullBoardGo.cpp"
#elif CURRENT_GAME == GAME_OTHELLO
#include "src/OTHELLO/FullBoardOthello.cpp"
#else
#error "Unsupported game selected"
#endif