// Wrapper per GameState.cpp
#if CURRENT_GAME == GAME_GO
#include "src/GO/GameStateGo.cpp"
#elif CURRENT_GAME == GAME_OTHELLO
#include "src/OTHELLO/GameStateOthello.cpp"
#else
#error "Unsupported game selected"
#endif


