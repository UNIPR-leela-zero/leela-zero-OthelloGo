#include "config.h"

// OpenCL.cpp (wrapper)
#if CURRENT_GAME == GAME_GO
#include "src/GO/OpenCLGo.cpp"
#elif CURRENT_GAME == GAME_OTHELLO
#include "src/OTHELLO/OpenCLOthello.cpp"
#else
#error "Unsupported game selected"
#endif
