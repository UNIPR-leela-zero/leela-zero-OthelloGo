#include "config.h"

#if CURRENT_GAME == GAME_GO
#include "src/GO/OpenCLSchedulerGo.cpp"
#elif CURRENT_GAME == GAME_OTHELLO
#include "src/OTHELLO/OpenCLSchedulerOthello.cpp"
#else
#error "Unsupported game selected"
#endif
