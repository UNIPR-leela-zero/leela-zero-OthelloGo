#include "config.h"

// FastBoard.cpp (wrapper)
#if CURRENT_GAME == GAME_GO
#include "src/GO/FastBoardGo.cpp"
#elif CURRENT_GAME == GAME_OTHELLO
#include "src/OTHELLO/FastBoardOthello.cpp"
#else
#error "Unsupported game selected"
#endif
