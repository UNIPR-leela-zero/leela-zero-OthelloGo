#ifndef OPENCLSCHEDULER_H_INCLUDED
#define OPENCLSCHEDULER_H_INCLUDED

#if CURRENT_GAME == GAME_GO
#include "src/GO/OpenCLSchedulerGo.h"
#elif CURRENT_GAME == GAME_OTHELLO
#include "src/OTHELLO/OpenCLSchedulerOthello.h"
#else
#error "Unsupported game selected"
#endif

#endif
