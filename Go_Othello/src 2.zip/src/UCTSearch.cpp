#include "config.h"

// Seleziona il file sorgente appropriato in base al gioco corrente
#if CURRENT_GAME == GAME_GO
#include "src/GO/UCTSearchGo.cpp"
#elif CURRENT_GAME == GAME_OTHELLO
#include "src/OTHELLO/UCTSearchOthello.cpp"
#else
#error "Unsupported game selected"
#endif