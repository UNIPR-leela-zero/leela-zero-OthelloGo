#include "config.h"

// CPUPipe.cpp (wrapper)
#if CURRENT_GAME == GAME_GO
#include "src/GO/CPUPipeGo.cpp"
#elif CURRENT_GAME == GAME_OTHELLO
#include "src/OTHELLO/CPUPipeOthello.cpp"
#else
#error "Unsupported game selected"
#endif
