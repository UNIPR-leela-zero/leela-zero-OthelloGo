#include "config.h"

// TimeControl.cpp (wrapper)
#if CURRENT_GAME == GAME_GO
#include "src/GO/TimeControlGo.cpp"
#elif CURRENT_GAME == GAME_OTHELLO
#include "src/OTHELLO/TimeControlOthello.cpp"
#else
#error "Unsupported game selected"
#endif