#pragma once
enum class GameType {
    GO,
    OTHELLO
};

extern GameType CURRENT_GAME;
