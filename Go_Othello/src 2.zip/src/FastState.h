#ifndef FASTSTATE_H_INCLUDED
#define FASTSTATE_H_INCLUDED

#if CURRENT_GAME == GAME_GO
#include "src/GO/FastStateGo.h"
#elif CURRENT_GAME == GAME_OTHELLO
#include "src/OTHELLO/FastStateOthello.h"
#else
#error "Unsupported game selected"
#endif

#endif